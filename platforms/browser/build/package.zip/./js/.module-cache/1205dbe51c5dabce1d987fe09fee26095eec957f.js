var Page = React.createClass({displayName: "Page",
	render : function(){
		return React.createElement("div", {className: this.props.pageId})
	}
});