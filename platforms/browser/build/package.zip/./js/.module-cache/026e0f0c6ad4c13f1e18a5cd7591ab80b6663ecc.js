define( "jquerymobile", [ "../../../jquery.mobile" ], function() {} );
